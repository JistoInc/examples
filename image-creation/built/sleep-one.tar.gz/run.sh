#!/bin/bash
#
# sleeping one second
#
sleep 1
