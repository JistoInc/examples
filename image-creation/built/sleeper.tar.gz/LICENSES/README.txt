* stress
  Stress is released under the GPLv2.

  Source code is available below:
  http://gnu.gds.tuwien.ac.at/directory/sysadmin/monitor/stress.html
