default['yum-scl']['repos']['scientific'] = default['yum-scl']['repos']['centos']
