# Memory

This example image utilizes the stress utility to increase
memory utilization.

A random (1/4 - 3/4) amount of free memory will be consumed
for random periods of time.

## Requirements

* none
