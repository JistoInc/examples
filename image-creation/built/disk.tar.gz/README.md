# disks

This example image utilizes the stress utility to increase
Disk utilization.

A random number of disk write threads will execute
for random periods of time.

## Requirements

* none
