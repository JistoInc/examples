#!/bin/bash
#
# Sleep for exactly one seconds.
#
# This runs at task start time.
#
sleep 1
