#!/bin/bash
#
# This gets run at image creation time - not at system boot time.  
#
# If you wish to copy chef server certificates into place, or do any
# generic custom configuration, do that here.
#
