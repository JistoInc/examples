# Sleep (do nothing) for one second

This example image sleeps (does nothing), for one second.

## Requirements

* None
