#!/bin/bash
#
# This gets run at image creation time - not at system boot time.  
#
true
