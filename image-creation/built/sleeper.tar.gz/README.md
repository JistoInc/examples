# Sleep (do nothing) for a specified number of seconds

This example image sleeps (does nothing), for a user-specified number of seconds. The default is 30 seconds, and can be set with the environment variable *SLEEP_TIME* in the image (in the file named *run.sh*) to the desired duration of the sleep.

## Requirements

* None
