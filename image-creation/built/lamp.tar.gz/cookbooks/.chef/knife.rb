cookbook_path [ '/home/patricia/lamp/lamp/cookbooks' ]
