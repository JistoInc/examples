#!/bin/bash
#
# This gets run at image creation time - not at system boot time.  
#
# Copy certificates into place, and generally configure static 
# image at system build time. 
